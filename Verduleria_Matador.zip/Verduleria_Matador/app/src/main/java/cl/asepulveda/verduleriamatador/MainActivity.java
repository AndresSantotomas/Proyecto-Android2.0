package cl.asepulveda.verduleriamatador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void catalogo(View view){
        Intent intent = new Intent(MainActivity.this,catalogo.class);
        startActivity(intent);
    }

    public void pedidos(View view){
        Intent intent2 = new Intent(MainActivity.this,pedidos.class);
        startActivity(intent2);
    }

    public void contacto(View view){
        Intent intent3 =  new Intent(MainActivity.this,contacto.class);
        startActivity(intent3);
    }
}