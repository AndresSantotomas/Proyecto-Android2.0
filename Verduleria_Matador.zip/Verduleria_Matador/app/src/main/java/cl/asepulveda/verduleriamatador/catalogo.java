package cl.asepulveda.verduleriamatador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class catalogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalogo);
    }
}