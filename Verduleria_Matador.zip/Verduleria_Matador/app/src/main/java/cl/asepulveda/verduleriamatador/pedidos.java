package cl.asepulveda.verduleriamatador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class pedidos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedidos);
    }

    public void seguir(View view) {
        Intent intent4 = new Intent(pedidos.this,seguimiento.class);
        startActivity(intent4);
    }

    public void mapls(View view) {
        Intent intent5= new Intent(pedidos.this,googlemaps.class);
        startActivity(intent5);
    }
}